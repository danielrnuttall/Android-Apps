package com.example.assignment1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private Button calcBut;
    private RecyclerView recyclerView;

    protected RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager mLayoutManager;

    public SharedPreferences.Editor editor;
    public SharedPreferences sharedPref;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true );
        mLayoutManager = new LinearLayoutManager(this);
        adapter = new DiaryAdapter(this, DiaryBook.getEntries());

        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setAdapter(adapter);


        sharedPref = getSharedPreferences("dailyEntry", Activity.MODE_PRIVATE);
        editor = sharedPref.edit();

        String entryJSON = sharedPref.getString("entry", "[]"); //if is empty

        if (DiaryBook.entry == null)
        {
            JSONHandling(entryJSON);
        }


        calcBut = findViewById(R.id.calcButton);
        calcBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, activity_calculator.class);
                startActivity(intent);
            }
        });


    }
    private void JSONHandling(String sons)
    {
        JSONArray jsonArr = null;

        try
        {
            jsonArr = new JSONArray(sons);
        }
        catch(JSONException j)
        {
            j.printStackTrace();
        }
        for (int k = 0; k <jsonArr.length();k++)
        {
            try
            {
                DiaryBook.addEntry((String) jsonArr.get(k));

            }
            catch(JSONException e)
            {
                e.printStackTrace();
            }
        }
    }


    public void onStart() {
        super.onStart();
        adapter.notifyDataSetChanged();
    }
    public void clearEntries()
    {
        DiaryBook.clear();
        adapter.notifyDataSetChanged();
    }
    private void save()
    {
        JSONArray entries = new JSONArray(DiaryBook.getEntries());

        editor.putString("entry", entries.toString());
        editor.apply();
    }
    public void onDestroy()
    {
        save();
        super.onDestroy();
    }
    public void finish()
    {
        save();
        super.finish();
    }


    public void updateAdapter(DiaryBook dbItem)
    {

        adapter.notifyDataSetChanged();
    }

}

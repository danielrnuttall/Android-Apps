package com.example.assignment1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DiaryAdapter extends RecyclerView.Adapter<DiaryAdapter.MyViewHolder>
{
    private Context context;
    private ArrayList<String> diaryList;


    public DiaryAdapter(Context context, ArrayList<String> diaryList)
    {
        this.diaryList = diaryList;
        this.context = context;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.itemlayout, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        //holder.itemTxtView.setText(diaryList.get(position));
       // diaryList = DiaryBook.getEntries();
        diaryList = DiaryBook.getDates();
        String t = diaryList.get(position);
        diaryList = DiaryBook.getEntries();
        String net = diaryList.get(position);
        holder.netTotal.setText(t + " " + net + "NKI");

        /*diaryList = DiaryBook.getCat();
        String d = diaryList.get(position);
        holder.dateView.setText(d);*/

    }

    @Override
    public int getItemCount() {
        return diaryList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder
    {
        TextView netTotal, date;

        public MyViewHolder(View itemView)
        {
            super(itemView);

            netTotal = itemView.findViewById(R.id.itemTextView);

        }
    }

}

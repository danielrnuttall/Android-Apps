package com.example.assignment1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
//import androidx.recyclerview.widget.LinearLayoutManager;
//import androidx.recyclerview.widget.RecyclerView;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import android.preference.PreferenceManager;
import android.view.View;

import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;

//JSON imports below:
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class activity_calculator extends AppCompatActivity implements DatePickerDialog.OnDateSetListener {

    private EditText mealEdtTxt;
    private EditText snackEdtTxt;
    private EditText gymEdtTxt;
    private EditText runEdtTxt;

    private TextView totalIntakeText;
    private TextView totalFoodText;
    private TextView totalExerciseText;
    private TextView dateTxtView;
    private int foodTotal = 0, exerciseTotal = 0, total = 0;
    private int snackSave = 0, mealSave = 0, gymSave = 0, runSave = 0;
    //private MainActivity mainAct;
    private String currDateStr = "";
    //recycler view stuff:
    //ArrayList<DiaryBook> diaryBookList = new ArrayList<>();
    DiaryBook db = new DiaryBook();
   // private RecyclerView mRecyclerView;
    private DiaryAdapter dAdapter;
    private Intent viewEntryAct;

    //private RecyclerView.LayoutManager mLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);

        viewEntryAct = new Intent(this, EntryActivity.class);

        mealEdtTxt = findViewById(R.id.mealEditText);
        snackEdtTxt = findViewById(R.id.snackEditText);
        gymEdtTxt = findViewById(R.id.gymEditText);
        runEdtTxt = findViewById(R.id.runEditText);

        totalIntakeText = findViewById(R.id.intakeTotal);
        totalFoodText = findViewById(R.id.foodTotalID);
        totalExerciseText = findViewById(R.id.exerciseTotal);

        //Below is the code for the submit button
        Button submitBtn;
        submitBtn = findViewById(R.id.submitButton);

        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int mealEntry;
                int snackEntry;
                int gymEntry;
                int runEntry;

                mealEntry = tryParse(mealEdtTxt.getText().toString());
                snackEntry = tryParse(snackEdtTxt.getText().toString());
                gymEntry = tryParse(gymEdtTxt.getText().toString());
                runEntry = tryParse(runEdtTxt.getText().toString());
                mealSave += mealEntry;
                snackSave += snackEntry;
                gymSave += gymEntry;
                runSave += runEntry;

                foodTotal = foodTotal + (mealEntry + snackEntry);
                exerciseTotal = exerciseTotal + (gymEntry + runEntry);
                total = foodTotal - exerciseTotal;

                totalIntakeText.setText(String.valueOf(total));
                totalFoodText.setText(String.valueOf(foodTotal));
                totalExerciseText.setText(String.valueOf(exerciseTotal));
                mealEntry = 0;
                snackEntry = 0;
                gymEntry = 0;
                runEntry = 0;

                //insertItem(String.valueOf(foodTotal), String.valueOf(exerciseTotal), String.valueOf(mealSave), String.valueOf(snackSave), String.valueOf(gymSave), String.valueOf(runSave), String.valueOf(total), currDateStr);
//String foodTotal, String exerciseTotal, String mealTotal, String snackTotal, String gymTotal, String runTotal, String netTotal, String dateEntry
                mealEdtTxt.setText("");
                snackEdtTxt.setText("");
                gymEdtTxt.setText("");
                runEdtTxt.setText("");


            }
        });
        //Below is code for the back and save button
        final Button backBtn = findViewById(R.id.backBtnID);
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*Intent intent = new Intent(activity_calculator.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);*/
                finish();
            }
        });
        final Button saveBtn = findViewById(R.id.btnSaveID);
        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveInputs();
            }
        });

        //Below is code for date button
        Button dateBtn = findViewById(R.id.dateBtnID);
        dateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogFragment datePicker = new DatePickerFragment();
                datePicker.show(getSupportFragmentManager(), "date picker");
            }
        });


    }

    @Override
    public void onDateSet(DatePicker datePicker, int year, int month, int day) {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.YEAR, year);
        c.set(Calendar.MONTH, month);
        c.set(Calendar.DAY_OF_MONTH, day);
        currDateStr = DateFormat.getDateInstance(DateFormat.FULL).format(c.getTime());

        dateTxtView = findViewById(R.id.dateDisplayTxtViewID);
        dateTxtView.setText(currDateStr);
    }

    public int tryParse(String valStr) {
        int numVal;
        try {
            numVal = Integer.parseInt(valStr);
        } catch (NumberFormatException e) {
            numVal = 0;
        }
        return numVal;
    }

    public void saveInputs() {

        DiaryBook.addEntry(String.valueOf(total));
        DiaryBook.addCat(String.valueOf(foodTotal));
        DiaryBook.addCat(String.valueOf(exerciseTotal));
        DiaryBook.addCat(String.valueOf(mealSave));
        DiaryBook.addCat(String.valueOf(snackSave));
        DiaryBook.addCat(String.valueOf(gymSave));
        DiaryBook.addCat(String.valueOf(runSave));
        //DiaryBook.addCat(currDateStr);
        DiaryBook.addDate(currDateStr);

        viewEntryAct.putExtra("entryTot", DiaryBook.getEntries().indexOf(String.valueOf(total)));

        viewEntryAct.putExtra("foodTot", DiaryBook.getCat().indexOf(String.valueOf(foodTotal)));
        viewEntryAct.putExtra("exerciseTot", DiaryBook.getCat().indexOf(String.valueOf(exerciseTotal)));
        viewEntryAct.putExtra("mealTot", DiaryBook.getCat().indexOf(String.valueOf(mealSave)));
        viewEntryAct.putExtra("snackTot", DiaryBook.getCat().indexOf(String.valueOf(snackSave)));
        viewEntryAct.putExtra("gymTot", DiaryBook.getCat().indexOf(String.valueOf(gymSave)));
        viewEntryAct.putExtra("runTot", DiaryBook.getCat().indexOf(String.valueOf(runSave)));
        //viewEntryAct.putExtra("date", DiaryBook.getCat().indexOf(currDateStr));
        viewEntryAct.putExtra("dateReal", DiaryBook.getDates().indexOf(currDateStr));

        Toast.makeText(this, "Saved!", Toast.LENGTH_SHORT).show();
        startActivity(viewEntryAct);


        finish();




    }

    @Override
    protected void onPause() {
        super.onPause();
        saveInputs();
    }

    protected void onResume() {
        super.onResume();

    }
    protected void onSaveInstanceState(Bundle outState)
    {
        super.onSaveInstanceState(outState);

    }

}




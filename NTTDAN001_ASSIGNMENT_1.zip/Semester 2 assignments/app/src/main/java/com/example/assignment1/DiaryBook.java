package com.example.assignment1;

import java.util.ArrayList;
import java.util.Date;

public class DiaryBook {

public static ArrayList<String> entry;
public static ArrayList<String>  catTotals;
public static ArrayList<String> dates;

    private String foodTotal, exerciseTotal, mealTotal, snackTotal, gymTotal, runTotal, netTotal, dateEntry;

    public static ArrayList<String> getEntries()
    {
        if (entry == null)
        {
            entry = new ArrayList<>();
        }
        return entry;
    }
    public static ArrayList<String> getDates()
    {
        if (dates == null)
        {
            dates = new ArrayList<>();
        }
        return dates;
    }
    public static ArrayList<String> getCat()
    {
        if (catTotals == null)
        {
            catTotals = new ArrayList<>();
        }
        return catTotals;
    }
    public static void addEntry(String entryItem)
    {
        if (entry == null)
        {
            entry = new ArrayList<>();
        }
        entry.add(entryItem);
    }

    public static void addDate(String dateItem)
    {
        if (dates == null)
        {
            dates = new ArrayList<>();
        }
        dates.add(dateItem);
    }
    public static void addCat(String category)
    {
        if (catTotals == null)
        {
            catTotals= new ArrayList<>();
        }
        catTotals.add(category);
    }
    public static void clear()
    {
        if (entry != null)
        {
            entry.clear();
        }
    }





    //constructors





    //setters/mutator methods





}

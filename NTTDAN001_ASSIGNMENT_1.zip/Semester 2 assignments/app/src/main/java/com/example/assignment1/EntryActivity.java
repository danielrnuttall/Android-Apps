package com.example.assignment1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toolbar;

import androidx.appcompat.app.AppCompatActivity;

public class EntryActivity extends AppCompatActivity
{
    private int netIndex,foodIndex,exIndex,mealIndex,snackIndex,gymIndex,runIndex,dateIndex;
    private String net, food, exercise, meal, snack, gym, run, date;
    private TextView netTotal, foodTotal, exTotal, dateV, mealVal, snackVal, gymVal, runVal;

    @Override
    protected void onCreate(Bundle saveInstanceState)
    {
        super.onCreate(saveInstanceState);
        setContentView(R.layout.activity_entry);



        netTotal = findViewById(R.id.netView);
        foodTotal = findViewById(R.id.foodView);
        exTotal = findViewById(R.id.exerciseView);
        dateV = findViewById(R.id.dateView);
        mealVal = findViewById(R.id.mealID);
        snackVal = findViewById(R.id.snackID);
        gymVal = findViewById(R.id.gymID);
        runVal = findViewById(R.id.runID);

        Button homeButton = findViewById(R.id.homeBtnID);
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(EntryActivity.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });

    }
protected void onStart()
{
    super.onStart();



    Intent recIntent = getIntent();
    Bundle extra = recIntent.getExtras();


    netIndex = extra.getInt("entryTot");
    net = DiaryBook.getEntries().get(netIndex);
    netTotal.setText(net);
    if (net.isEmpty())
    {
        net = "0";
    }


    foodIndex= extra.getInt("foodTot");
    food = DiaryBook.getCat().get(foodIndex);
    foodTotal.setText(food);
    if(food.isEmpty())
    {
        food = "0";
    }

    exIndex = extra.getInt("exerciseTot");
    exercise = DiaryBook.getCat().get(exIndex);
    exTotal.setText(exercise);
    if (exercise.isEmpty())
    {
        exercise = "0";
    }

    mealIndex = extra.getInt("mealTot");
    meal = DiaryBook.getCat().get(mealIndex);
    mealVal.setText(meal);
    if(meal.isEmpty())
    {
        meal = "0";
    }

    snackIndex = extra.getInt("snackTot");
    snack = DiaryBook.getCat().get(snackIndex);
    snackVal.setText(snack);
    if (snack.isEmpty())
    {
        snack = "0";
    }

    gymIndex = extra.getInt("gymTot");
    gym = DiaryBook.getCat().get(gymIndex);
    gymVal.setText(gym);
    if (gym.isEmpty())
    {
        gym = "0";
    }

    runIndex = extra.getInt("runTot");
    run = DiaryBook.getCat().get(runIndex);
    runVal.setText(run);
    if (run.isEmpty())
    {
        run = "0";
    }

    dateIndex = extra.getInt("date");
    date = DiaryBook.getDates().get(dateIndex);
    if (date.isEmpty())
    {
        date = "No date given.";
    }
    dateV.setText(date);

}
}
